/*
 * moh_matrixlab_sample.c
 *
 * Created: 2018-08-25 오후 5:48:33
 * Author : Lincoln
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "Timer.c"
#include "scheduler.h"
#define up 0x01
#define down 0x02
//=======================
//SM1: DEMO LED matrix
//=======================
enum SM1_States{sm1_init, sm1_wait, sm1_up, sm1_down};
int SM1_Tick(int state){
	//===========Local Variables============
	static unsigned char column_val = 0x01;//sets the pattern displayed on columns
	static unsigned char column_sel = 0x00;//grounds column to display pattern
	unsigned char button = ~PINA & 0x03;
	//=============transitions==============
	switch(state){
		case sm1_init:
		state = sm1_wait;
		break;
		
		case sm1_wait: 
		if(button == up)
		{
			state = sm1_up;
		}
		else if(button == down)
		{
			state = sm1_down;
		}
		else
		{
			state = sm1_wait;
		}
		break;
		
		case sm1_up:
		if(button == up)
		{
			state = sm1_up;
		}
		else
		{
			state = sm1_wait;
		}
		break;
		
		case sm1_down:
		if(button == down)
		{
			state = sm1_down;
		}
		else
		{
			state = sm1_wait;
		}
		break;
		
		default:
		state = sm1_init;
		break;
	}
	//===============actions================
	switch(state){
		case sm1_init:
		column_val = 0x01;
		column_sel = 0x00;
		break;
		
		case sm1_wait:	//if illuminated LED in bottom right corner
		break;
		
		case sm1_up:
		if(column_val == 0x80)
		{
			break;
		}
		else
		{
			column_val = (column_val << 1) | 0x00;
		}
		break;
		
		case sm1_down:
		if(column_val == 0x01)
		{
			break;
		}
		else
		{
			column_val = (column_val >> 1) | 0x00;
		}
		break;
		
		default:
		break;
	}
	PORTC = column_val;		//PORTC displays column pattern
	PORTB = column_sel;		//PORTB selects column to display pattern
	
	return state;
}

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;
	DDRC = 0xFF; PORTC = 0x00;
	DDRB = 0xFF; PORTB = 0x00;
	
	unsigned long int SM1_Tick_calc = 100;
	unsigned long int tmpGCD = 1;
	unsigned long int GCD = tmpGCD;
	unsigned long int SM1_Tick1_period = SM1_Tick_calc;
	
	static task task1;
	task *tasks[] = {&task1};
	const unsigned short numTasks = sizeof(tasks)/sizeof(task*);
	
	task1.state = 0;
	task1.period = SM1_Tick1_period;
	task1.elapsedTime = SM1_Tick1_period;
	task1.TickFct = &SM1_Tick;
	
	TimerSet(GCD);
	TimerOn();
	
	while(1)
	{
		for(unsigned int i = 0; i < numTasks; i++)
		{
			if(tasks[i]->elapsedTime >= tasks[i]->period)
			{
				tasks[i]->state = tasks[i]->TickFct(tasks[i]->state);
				tasks[i]->elapsedTime = 0;
			}
			tasks[i]->elapsedTime += 1;
		}
		while(!TimerFlag);
		TimerFlag = 0;
	}
}